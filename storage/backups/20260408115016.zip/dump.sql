-- CATMIN SQL dump
-- Generated: 2026-04-08T11:50:16+00:00
-- Driver: mysql

CREATE TABLE `admin_login_attempts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(191) NOT NULL,
  `ip_address` varchar(64) NOT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `attempted_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_admin_login_attempts_identifier` (`identifier`),
  KEY `ix_admin_login_attempts_attempted_at` (`attempted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_login_attempts` (`id`, `identifier`, `ip_address`, `success`, `attempted_at`) VALUES (1, 'Linkyear', '192.168.0.129', 1, '2026-04-08 09:52:46');
INSERT INTO `admin_login_attempts` (`id`, `identifier`, `ip_address`, `success`, `attempted_at`) VALUES (2, 'Linkyear', '192.168.0.129', 1, '2026-04-08 10:34:33');

CREATE TABLE `admin_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(140) NOT NULL,
  `slug` varchar(160) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_admin_permissions_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_permissions` (`id`, `name`, `slug`, `description`, `created_at`) VALUES (1, 'Access Dashboard', 'admin.dashboard.access', 'Access CATMIN admin dashboard', '2026-04-08 09:40:07');
INSERT INTO `admin_permissions` (`id`, `name`, `slug`, `description`, `created_at`) VALUES (2, 'Manage Users', 'admin.users.manage', 'Create/update/delete admin users', '2026-04-08 09:40:07');
INSERT INTO `admin_permissions` (`id`, `name`, `slug`, `description`, `created_at`) VALUES (3, 'Manage Roles', 'admin.roles.manage', 'Manage admin roles and permissions', '2026-04-08 09:40:07');
INSERT INTO `admin_permissions` (`id`, `name`, `slug`, `description`, `created_at`) VALUES (4, 'Manage Settings', 'core.settings.manage', 'Manage core settings', '2026-04-08 09:40:07');
INSERT INTO `admin_permissions` (`id`, `name`, `slug`, `description`, `created_at`) VALUES (5, 'View Logs', 'core.logs.view', 'Read security and system logs', '2026-04-08 09:40:07');

CREATE TABLE `admin_role_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_admin_role_permissions_pair` (`role_id`,`permission_id`),
  KEY `ix_admin_role_permissions_role_id` (`role_id`),
  KEY `ix_admin_role_permissions_permission_id` (`permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_role_permissions` (`id`, `role_id`, `permission_id`) VALUES (1, 1, 1);
INSERT INTO `admin_role_permissions` (`id`, `role_id`, `permission_id`) VALUES (2, 1, 2);
INSERT INTO `admin_role_permissions` (`id`, `role_id`, `permission_id`) VALUES (3, 1, 3);
INSERT INTO `admin_role_permissions` (`id`, `role_id`, `permission_id`) VALUES (4, 1, 4);
INSERT INTO `admin_role_permissions` (`id`, `role_id`, `permission_id`) VALUES (5, 1, 5);

CREATE TABLE `admin_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_admin_roles_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_roles` (`id`, `name`, `slug`, `is_system`, `created_at`) VALUES (1, 'SuperAdmin', 'super-admin', 1, '2026-04-08 09:40:07');

CREATE TABLE `admin_security_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `event_type` varchar(120) NOT NULL,
  `severity` varchar(40) NOT NULL,
  `payload` text DEFAULT NULL,
  `ip_address` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_admin_security_events_user_id` (`user_id`),
  KEY `ix_admin_security_events_event_type` (`event_type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_security_events` (`id`, `user_id`, `event_type`, `severity`, `payload`, `ip_address`, `created_at`) VALUES (1, 1, 'auth.login.success', 'info', '{\"ip\":\"192.168.0.129\"}', '192.168.0.129', '2026-04-08 09:52:46');
INSERT INTO `admin_security_events` (`id`, `user_id`, `event_type`, `severity`, `payload`, `ip_address`, `created_at`) VALUES (2, NULL, 'security.install.access_after_lock', 'warning', '{\"ip\":\"127.0.0.1\",\"path\":\"/\"}', '127.0.0.1', '2026-04-08 09:56:56');
INSERT INTO `admin_security_events` (`id`, `user_id`, `event_type`, `severity`, `payload`, `ip_address`, `created_at`) VALUES (3, NULL, 'security.install.access_after_lock', 'warning', '{\"ip\":\"127.0.0.1\",\"path\":\"/\"}', '127.0.0.1', '2026-04-08 10:00:47');
INSERT INTO `admin_security_events` (`id`, `user_id`, `event_type`, `severity`, `payload`, `ip_address`, `created_at`) VALUES (4, 1, 'auth.login.success', 'info', '{\"ip\":\"192.168.0.129\"}', '192.168.0.129', '2026-04-08 10:34:33');

CREATE TABLE `admin_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `session_token` varchar(191) NOT NULL,
  `ip_address` varchar(64) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `last_activity_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_admin_sessions_token` (`session_token`),
  KEY `ix_admin_sessions_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_sessions` (`id`, `user_id`, `session_token`, `ip_address`, `user_agent`, `last_activity_at`, `created_at`) VALUES (1, 1, 'f13786643ef3663ec43f46534b82ba9ae5ccb4bc4831ac50d7a13fe2b4143e91', '192.168.0.129', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-04-08 10:34:30', '2026-04-08 09:52:46');
INSERT INTO `admin_sessions` (`id`, `user_id`, `session_token`, `ip_address`, `user_agent`, `last_activity_at`, `created_at`) VALUES (2, 1, '255bb8c9feaccad768fc29ce71ec33e42bc2e4d75774f8cf97556ed3e7110bc8', '192.168.0.129', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:149.0) Gecko/20100101 Firefox/149.0', '2026-04-08 11:50:16', '2026-04-08 10:34:33');

CREATE TABLE `admin_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) unsigned NOT NULL,
  `username` varchar(120) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_admin_users_username` (`username`),
  UNIQUE KEY `ux_admin_users_email` (`email`),
  KEY `ix_admin_users_role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_users` (`id`, `role_id`, `username`, `email`, `password_hash`, `is_active`, `last_login_at`, `created_at`, `updated_at`) VALUES (1, 1, 'Linkyear', 'linkyear@gmail.com', '$argon2id$v=19$m=65536,t=4,p=1$UmY3VTF2L3BWd0k3bTlVUw$iSbakJDqICRV6YWPlmDuBPTu1JethwVwjbkliTOz3us', 1, '2026-04-08 10:34:33', '2026-04-08 09:40:07', '2026-04-08 10:34:33');

CREATE TABLE `core_backups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `backup_type` varchar(40) NOT NULL,
  `status` varchar(40) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `checksum` varchar(191) DEFAULT NULL,
  `size_bytes` bigint(20) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_core_backups_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `core_cron_tasks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `script_path` varchar(255) NOT NULL,
  `schedule_expr` varchar(120) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `last_run_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_core_cron_tasks_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `core_cron_tasks` (`id`, `name`, `script_path`, `schedule_expr`, `is_active`, `last_run_at`, `created_at`, `updated_at`) VALUES (1, 'Core Cache Cleanup', 'core/cron/core-cache-cleanup.php', '0 */6 * * *', 0, NULL, '2026-04-08 09:40:07', '2026-04-08 09:40:07');
INSERT INTO `core_cron_tasks` (`id`, `name`, `script_path`, `schedule_expr`, `is_active`, `last_run_at`, `created_at`, `updated_at`) VALUES (2, 'Core Logs Rotate', 'core/cron/core-logs-rotate.php', '10 2 * * *', 0, NULL, '2026-04-08 09:40:07', '2026-04-08 09:40:07');
INSERT INTO `core_cron_tasks` (`id`, `name`, `script_path`, `schedule_expr`, `is_active`, `last_run_at`, `created_at`, `updated_at`) VALUES (3, 'Core Health Check', 'core/cron/core-health-check.php', '*/15 * * * *', 0, NULL, '2026-04-08 09:40:07', '2026-04-08 09:40:07');

CREATE TABLE `core_db_versions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `schema_version` varchar(64) NOT NULL,
  `batch` int(11) NOT NULL DEFAULT 1,
  `applied_at` datetime NOT NULL DEFAULT current_timestamp(),
  `checksum` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_core_db_versions_migration` (`migration`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `core_db_versions` (`id`, `migration`, `schema_version`, `batch`, `applied_at`, `checksum`) VALUES (1, '001_create_catmin_base_tables.php', '0.1.0-dev.2', 1, '2026-04-08 09:40:00', NULL);
INSERT INTO `core_db_versions` (`id`, `migration`, `schema_version`, `batch`, `applied_at`, `checksum`) VALUES (2, '002_add_checksum_to_db_versions.php', '0.1.0-dev.2', 2, '2026-04-08 09:40:07', 'd89065caa2b2c23c20709771dbb5ede3a195edbfadc4602f83bfe4227f21683e');

CREATE TABLE `core_document_acceptances` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` bigint(20) unsigned NOT NULL,
  `subject_type` varchar(40) NOT NULL,
  `subject_id` bigint(20) NOT NULL,
  `ip_address` varchar(64) DEFAULT NULL,
  `accepted_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_core_doc_acceptances_unique` (`document_id`,`subject_type`,`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `core_documents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(120) NOT NULL,
  `title` varchar(191) NOT NULL,
  `version` varchar(64) NOT NULL,
  `content` text NOT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 1,
  `published_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_core_documents_code_version` (`code`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `core_install` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `install_uuid` varchar(64) NOT NULL,
  `instance_uuid` varchar(64) NOT NULL,
  `primary_domain` varchar(191) NOT NULL,
  `installed_version` varchar(64) NOT NULL,
  `consent_tracking` tinyint(1) NOT NULL DEFAULT 0,
  `installed_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `core_install` (`id`, `install_uuid`, `instance_uuid`, `primary_domain`, `installed_version`, `consent_tracking`, `installed_at`) VALUES (1, '072dc731943bd200284b9b0dfce49c69', '26446d8fc9dd71012ae8cc341c9f2b25', 'catmin.local', '0.3.0-dev.4', 0, '2026-04-08 09:40:07');

CREATE TABLE `core_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `channel` varchar(80) NOT NULL,
  `level` varchar(40) NOT NULL,
  `message` text NOT NULL,
  `context` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_core_logs_level` (`level`),
  KEY `ix_core_logs_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (1, 'system', 'WARNING', 'Maintenance desactivee', '{\"level\":3,\"reason\":\"\",\"enabled_by\":\"Linkyear\"}', '2026-04-08 10:43:29');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (2, 'system', 'WARNING', 'Maintenance desactivee', '{\"level\":1,\"reason\":\"\",\"enabled_by\":\"Linkyear\"}', '2026-04-08 10:43:36');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (3, 'backup', 'INFO', 'Backup manuel cree', '{\"file\":\"backup-20260408-104337.txt\",\"size\":52}', '2026-04-08 10:43:37');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (4, 'system', 'WARNING', 'Maintenance desactivee', '{\"level\":2,\"reason\":\"\",\"enabled_by\":\"Linkyear\"}', '2026-04-08 10:44:12');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (5, 'backup', 'INFO', 'Backup manuel cree', '{\"file\":\"backup-20260408-104413.txt\",\"size\":52}', '2026-04-08 10:44:13');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (6, 'system', 'WARNING', 'Maintenance desactivee', '{\"level\":3,\"reason\":\"\",\"enabled_by\":\"Linkyear\"}', '2026-04-08 10:44:19');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (7, 'backup', 'INFO', 'Backup manuel cree', '{\"file\":\"backup-20260408-104420.txt\",\"size\":52}', '2026-04-08 10:44:20');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (8, 'backup', 'WARNING', 'Backup supprime', '{\"file\":\"backup-20260408-104420.txt\"}', '2026-04-08 11:39:40');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (9, 'backup', 'WARNING', 'Backup supprime', '{\"file\":\"backup-20260408-104413.txt\"}', '2026-04-08 11:39:41');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (10, 'backup', 'WARNING', 'Backup supprime', '{\"file\":\"backup-20260408-104337.txt\"}', '2026-04-08 11:39:42');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (11, 'backup', 'INFO', 'Backup manuel cree', '{\"file\":\"backup-20260408-113943.json\",\"size\":185}', '2026-04-08 11:39:43');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (12, 'backup', 'WARNING', 'Backup supprime', '{\"file\":\"backup-20260408-113943.json\"}', '2026-04-08 11:39:56');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (13, 'system', 'WARNING', 'Maintenance desactivee', '{\"level\":3,\"reason\":\"\",\"enabled_by\":\"Linkyear\"}', '2026-04-08 11:50:04');
INSERT INTO `core_logs` (`id`, `channel`, `level`, `message`, `context`, `created_at`) VALUES (14, 'backup', 'WARNING', 'Backup supprime', '{\"file\":\"20260408114815.json\"}', '2026-04-08 11:50:15');

CREATE TABLE `core_modules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `version` varchar(64) NOT NULL,
  `status` varchar(40) NOT NULL DEFAULT 'inactive',
  `installed_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_core_modules_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `core_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `target_type` varchar(60) NOT NULL,
  `target_id` bigint(20) DEFAULT NULL,
  `title` varchar(191) NOT NULL,
  `body` text DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_core_notifications_target` (`target_type`,`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `core_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(120) NOT NULL,
  `setting_key` varchar(160) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_core_settings_unique` (`category`,`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (1, 'app', 'name', 'CATMIN', 1, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (2, 'app', 'url', '/', 1, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (3, 'system', 'timezone', 'Europe/Brussels', 1, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (4, 'security', 'admin_path', 'catmin', 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (5, 'security', 'ip_whitelist_enabled', 0, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (6, 'security', 'ip_whitelist', '[]', 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (7, 'general', 'app_name', 'CATMIN', 1, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (8, 'general', 'app_env', 'production', 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (9, 'general', 'timezone', 'Europe/Brussels', 1, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (10, 'general', 'admin_path', 'catmin', 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (11, 'security', 'session_minutes', 120, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (12, 'security', 'max_attempts', 5, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (13, 'security', 'password_min', 12, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (14, 'security', 'enforce_2fa', 0, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (15, 'email', 'enabled', 0, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (16, 'email', 'driver', 'smtp', 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (17, 'email', 'from_name', 'CATMIN', 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (18, 'email', 'from_email', 'noreply@catmin.local', 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (19, 'email', 'host', '', 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (20, 'email', 'port', 587, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (21, 'email', 'encryption', 'tls', 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (22, 'email', 'username', '', 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (23, 'ui', 'theme_default', 'corporate', 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (24, 'ui', 'compact_sidebar', 1, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (25, 'ui', 'table_density', 'comfortable', 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (26, 'ui', 'show_debug', 0, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (27, 'maintenance', 'enabled', 0, 0, '2026-04-08 11:50:04');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (28, 'maintenance', 'message', 'Maintenance en cours', 0, '2026-04-08 11:50:04');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (29, 'maintenance', 'allow_admin', 1, 0, '2026-04-08 11:50:04');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (30, 'maintenance', 'last_backup', '2026-04-08 11:39:43', 0, '2026-04-08 11:50:04');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (31, 'maintenance', 'last_restore', '-', 0, '2026-04-08 11:50:04');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (32, 'system', 'cron_enabled', 1, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (33, 'security', 'admin_reauth_required', 1, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (34, 'security', 'reauth_ttl_seconds', 900, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (35, 'security', 'session_lifetime', 7200, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (36, 'security', 'bind_session_fingerprint', 1, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (37, 'security', 'csrf_rotate_on_validation', 1, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (38, 'security', 'superadmin_email_reset', 0, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (39, 'security', 'admin_password_min', 12, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (40, 'security', 'admin_password_require_upper', 1, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (41, 'security', 'admin_password_require_lower', 1, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (42, 'security', 'admin_password_require_digit', 1, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (43, 'security', 'admin_password_require_symbol', 1, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (44, 'security', 'progressive_lockout', 1, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (45, 'security', 'lockout_window_minutes', 30, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (46, 'security', 'admin_noindex', 1, 0, '2026-04-08 09:40:07');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (47, 'maintenance', 'level', 3, 0, '2026-04-08 11:50:04');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (48, 'maintenance', 'reason', '', 0, '2026-04-08 11:50:04');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (49, 'maintenance', 'allowed_ips', '', 0, '2026-04-08 11:50:04');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (50, 'maintenance', 'allowed_admin_ids', '', 0, '2026-04-08 11:50:04');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (51, 'maintenance', 'started_at', '', 0, '2026-04-08 11:50:04');
INSERT INTO `core_settings` (`id`, `category`, `setting_key`, `setting_value`, `is_public`, `updated_at`) VALUES (52, 'maintenance', 'enabled_by', 'Linkyear', 0, '2026-04-08 11:50:04');

CREATE TABLE `front_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_front_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

